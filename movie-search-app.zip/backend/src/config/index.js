module.exports = {

  baseUrl: 'http://www.omdbapi.com/',
  omdbAccessToken: process.env.OMDb_PERSONAL_ACCESS_TOKEN
  // omdbAccessToken: require('./token'),
  }